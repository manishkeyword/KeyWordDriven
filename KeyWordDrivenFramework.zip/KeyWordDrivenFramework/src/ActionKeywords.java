import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ActionKeywords 
{	
	public static WebDriver driver;
	
	public static void waitForElement(WebElement element)
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(driver,30);	
		
			wait.until(ExpectedConditions.visibilityOf(element));					
		}
		catch(TimeoutException te)
		{
			throw new Error("Timed out after 30 seconds. Element "+element+" could not be located");
		}
		catch(NoSuchElementException ne)
		{
			throw new Error("Timed out after 30 seconds. Element "+element+" could not be located");
		}
	}
	
	public static void openBrowser(String browser)
	{		
		switch(browser.toUpperCase()) //converting to uppercase will be robust
		{
			case "FIREFOX" :
			
			DesiredCapabilities cap = new DesiredCapabilities();
			
			cap.setCapability("marionette", true);
			
			System.setProperty("webdriver.gecko.driver", "drivers/geckodriver.exe");
			
			driver = new FirefoxDriver(cap);
			
			break;
		}		
	}
	
	public static void navigateToURL(String url)
	{
		driver.get(url);
	}
	
	/****************************************************************************************************************** 
	 * This method is to enter value in any element
	 * In this we are passing parameters as xpath and the value to enter
	 ******************************************************************************************************************/
	public static void inputValue(String xpath, String value)
	{		
		WebElement element = driver.findElement(By.xpath(xpath));
		
		waitForElement(element);
		
		element.clear();
		
		element.sendKeys(value);		
	}
	
	
	/****************************************************************************************************************** 
	 * This method is to click any element
	 * In this we are passing parameters as xpath 
	 ******************************************************************************************************************/
	public static void click(String xpath)
	{
		WebElement element = driver.findElement(By.xpath(xpath));
		
		waitForElement(element);
		
		element.click();				
	}
	
	public static void closeBrowser()
	{
		try 
		{
			Thread.sleep(3000); //this is just for the user to see that an event occurred before closing the browser
		} 
		catch (InterruptedException e) 
		{		
			e.printStackTrace();
		} 
		driver.close(); //or quit to quit all
	}
}
