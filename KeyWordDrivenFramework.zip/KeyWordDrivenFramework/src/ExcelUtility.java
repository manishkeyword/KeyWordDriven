import java.io.File;
import java.io.FileInputStream;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;


public class ExcelUtility 
{
	private static Workbook ExcelWBook;				

	private static Sheet ExcelWSheet;
	
	/****************************************************************************************************************** 
	 * This method is to set the File path and to open the Excel file
	 * Pass Excel Path and SheetName as Arguments to this method
	 ******************************************************************************************************************/
	public static void setExcelFile(String path,String sheetName) throws Exception 
	{
		FileInputStream ExcelFile = new FileInputStream(path);

		ExcelWBook = new HSSFWorkbook(ExcelFile);

		ExcelWSheet = ExcelWBook.getSheet(sheetName);
	}

    /****************************************************************************************************************** 
	 * This method is to read the test data from the Excel cell
	 * In this we are passing parameters/arguments as Row Num and Col Num
	 ******************************************************************************************************************/
    public static String getCellData(int RowNum, int ColNum) throws Exception
    {
	  return ExcelWSheet.getRow(RowNum).getCell(ColNum).toString();
	}
    
    public static int getLastRowNum()
    {
    	return ExcelWSheet.getLastRowNum();
    }
}
