public class TestRunner
{
	public static String strActionKeyword;		
	
	public static void main(String[] args) throws Exception 
	{		
		ExcelUtility.setExcelFile(Constants.TEST_CASE_FILE,Constants.TEST_CASE_SHEET);		
		
		for (int iRow=1;iRow<=ExcelUtility.getLastRowNum();iRow++)
		{		    
			strActionKeyword = ExcelUtility.getCellData(iRow, Constants.KEYWORD_COLUMN); 			

			if(strActionKeyword.equals("openBrowser"))
			{   
				System.out.println("Opening "+Constants.BROWSER_TYPE+" browser");

				ActionKeywords.openBrowser(Constants.BROWSER_TYPE);
			}
			else if(strActionKeyword.equals("navigateToURL"))
			{
				System.out.println("Navigating to URL");

				ActionKeywords.navigateToURL(Constants.PAGE_URL);
			}			
			else if(strActionKeyword.equals("closeBrowser"))
			{
				System.out.println("Closing "+Constants.BROWSER_TYPE+" browser");

				ActionKeywords.closeBrowser();
			}
			else if(strActionKeyword.contains("input"))
			{
				System.out.println("Entering "+ strActionKeyword.split("_")[1]);

				String xpath = ExcelUtility.getCellData(iRow, Constants.XPATH_COLUMN); 

				String value = ExcelUtility.getCellData(iRow, Constants.VALUE_COLUMN); 

				ActionKeywords.inputValue(xpath, value);
			}
			else if(strActionKeyword.isEmpty()) //i am assuming that we put one blank row after every page
			{
				System.out.println("=====================Test case completed=================");

				System.out.println("Starting new test case");
			}		
		}
	}	
}

/****************************************************************************************************************** 
 * To prepare test results. We can generate one excel everytime we start execution 
 * and then update the results before closing the browser
 * The excel must have the test case id, name and result column
 * if the validation fails or if there is an exception, then the result must be updated in the excel using catch block
 ******************************************************************************************************************/
