/****************************************************************************************************************** 
* We can use a property file but here I am just using a simple method
******************************************************************************************************************/
public class Constants 
{
	public static final String TEST_CASE_FILE = "testcases/TestCaseEngine.xls";
	
	public static final String TEST_CASE_SHEET = "testcases";
	
	public static final String BROWSER_TYPE = "firefox"; //we can read this value from Jenkins to run crossbrowser testing
	
	public static final String PAGE_URL = "file:///C:/KeyWordDrivenFramework/samplewebpage/SampleLoginPage.html";  //application url
	
	public static final int KEYWORD_COLUMN = 4;
	
	public static final int XPATH_COLUMN = 5;
	
	public static final int VALUE_COLUMN = 6;
}
